<footer>
        <div class="container">
        <p class="copyright">&copy; <?php echo date('Y'); ?> Webpaint. All rights reserved.</p>
        </div>
    </footer>
