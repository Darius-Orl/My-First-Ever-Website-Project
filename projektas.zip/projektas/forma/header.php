<header class= "site-header">
        <div class="container flex-container">
            <div class="logo">
                <a href="#"><img src="../images/logo.png" alt="Brush"></a>
                <a href="#"><img src="../images/logotext.png" alt="Web Paint"></a>
            </div>
               <nav class="main-nav">
                 <ul class="flex-container">
                   <li><a href="#home">Home</a></li>
                   <li><a href="#portfolio">Portfolio</a></li>
                   <li><a href="#services">About</a></li>
                   <li><a href="#">Blog</a></li>
                   <li><a href="#contact">Contact</a></li>
                 </ul>
               </nav>
        </div>
    </header>