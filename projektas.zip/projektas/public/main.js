const scroll = new SmoothScroll('a[href*="#"]', {
	speed: 800
});



