<header class= "site-header">
        <div class="container flex-container">
            <div class="logo">
                <a href="#"><img src="../images/logo.png" alt="Brush"></a>
                <a href="#"><img src="../images/logotext.png" alt="Web Paint"></a>
            </div>
               <nav class="main-nav">
                 <ul class="flex-container">
                   <li><a class="scroll" href="#">Home</a></li>
                   <li><a class="scroll" href="#">Portfolio</a></li>
                   <li><a class="scroll" href="#">About</a></li>
                   <li><a class="scroll" href="#">Blog</a></li>
                   <li><a class="scroll" href="#">Contact</a></li>
                 </ul>
               </nav>
        </div>
    </header>